from bench_phys.ask_nodes import num_nodes
