import subprocess

def wrong():
    with open('md.log', 'w') as f:
        f.write('Performance:       0.00        0.00' + "\n")
        f.close
    
    subprocess.check_call('for i in script_*;do cp -vn md.log ${i}/;done', shell=True)
    subprocess.check_call("while IFS= read -r filename; do >   { echo "Performance:       1.00        1.00"; cat "$filename"; } > tmpfile && mv tmpfile "$filename" > done < <(find . -name \*.log -print)",shell=True)
