from phys_benchmark.ask_nodes import num_nodes
